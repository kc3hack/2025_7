"use client";
import React from "react";
import PlayerStatus from "../components/player-status";
import Dice from "../components/dice";
import GameBoard from "../components/game-board";

function MainComponent() {
  const [gameStarted, setGameStarted] = useState(false);
  const [position, setPosition] = useState(0);
  const [debt, setDebt] = useState(5000000);
  const [money, setMoney] = useState(0);
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleRoll = useCallback(
    async (value) => {
      if (!gameStarted) return;

      const newPosition = Math.min(position + value, 10);
      setPosition(newPosition);

      setLoading(true);
      try {
        const spaces = [
          { id: 0, name: "スタート", location: "大阪" },
          { id: 1, name: "難波", location: "大阪" },
          { id: 2, name: "道頓堀", location: "大阪" },
          { id: 3, name: "USJ", location: "大阪" },
          { id: 4, name: "京都駅", location: "京都" },
          { id: 5, name: "清水寺", location: "京都" },
          { id: 6, name: "伏見稲荷", location: "京都" },
          { id: 7, name: "姫路城", location: "兵庫" },
          { id: 8, name: "神戸港", location: "兵庫" },
          { id: 9, name: "なんばグランド花月", location: "大阪" },
          { id: 10, name: "ゴール", location: "大阪" },
        ];

        const response = await fetch("/api/generate-event", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ location: spaces[newPosition].location }),
        });

        const data = await response.json();
        if (data.error) {
          throw new Error(data.error);
        }

        setEvent(data);
        setMoney((prev) => prev + data.amount);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    },
    [gameStarted, position]
  );

  const handleStart = () => {
    setGameStarted(true);
  };

  const handleReset = () => {
    setGameStarted(false);
    setPosition(0);
    setDebt(5000000);
    setMoney(0);
    setEvent(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-r from-[#ffd700] to-[#ff8c00] p-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-[#800000] mb-4 font-crimson-text">
            関西完済すごろく
          </h1>
          <p className="text-xl text-[#800000]">
            借金500万円を返済しながら関西を巡る爆笑すごろくゲーム！
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-8 items-start">
          <div className="w-full md:w-3/4 space-y-8">
            <div className="flex justify-center">
              <Dice onRoll={handleRoll} />
            </div>

            <div className="flex justify-center">
              <GameBoard currentPosition={position} />
            </div>

            <div className="bg-white rounded-xl p-6 shadow-lg">
              <h2 className="text-2xl font-bold text-[#800000] mb-4">
                イベント
              </h2>
              {loading ? (
                <p className="text-gray-600">ローディング中...</p>
              ) : event ? (
                <div className="space-y-2">
                  <p className="text-lg">{event.event}</p>
                  <p className="text-lg">{event.result}</p>
                  <p
                    className={`text-lg font-bold ${
                      event.amount >= 0 ? "text-green-600" : "text-red-600"
                    }`}
                  >
                    {event.amount >= 0 ? "+" : ""}
                    {event.amount.toLocaleString()}円
                  </p>
                </div>
              ) : (
                <p className="text-gray-600">
                  サイコロを振ってゲームを進めよう！
                </p>
              )}
            </div>
          </div>

          <div className="w-full md:w-1/4">
            <PlayerStatus debt={debt} money={money} />

            <div className="mt-4 space-y-4">
              {!gameStarted ? (
                <button
                  onClick={handleStart}
                  className="w-full py-3 bg-[#ff4500] hover:bg-[#ff6347] text-white font-bold rounded-lg shadow-lg transform hover:scale-105 transition"
                >
                  スタート！
                </button>
              ) : (
                <button
                  onClick={handleReset}
                  className="w-full py-3 bg-[#800000] hover:bg-[#a52a2a] text-white font-bold rounded-lg shadow-lg transform hover:scale-105 transition"
                >
                  リセット
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;