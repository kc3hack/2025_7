"use client";
import React from "react";

function GameBoard({ currentPosition = 0 }) {
  const spaces = [
    { id: 0, name: "スタート", location: "大阪" },
    { id: 1, name: "難波", location: "大阪" },
    { id: 2, name: "道頓堀", location: "大阪" },
    { id: 3, name: "USJ", location: "大阪" },
    { id: 4, name: "京都駅", location: "京都" },
    { id: 5, name: "清水寺", location: "京都" },
    { id: 6, name: "伏見稲荷", location: "京都" },
    { id: 7, name: "姫路城", location: "兵庫" },
    { id: 8, name: "神戸港", location: "兵庫" },
    { id: 9, name: "なんばグランド花月", location: "大阪" },
    { id: 10, name: "ゴール", location: "大阪" },
  ];

  return (
    <div className="w-full max-w-[800px] p-4 bg-[#f5f5f5] rounded-xl">
      <div className="flex flex-wrap gap-4 justify-center">
        {spaces.map((space) => (
          <div
            key={space.id}
            className={`w-[120px] h-[120px] p-2 rounded-lg flex flex-col items-center justify-center text-center ${
              currentPosition === space.id
                ? "bg-[#ffd700] border-2 border-[#ffa500]"
                : "bg-white border border-gray-200"
            }`}
          >
            <div className="text-sm font-bold mb-1">{space.name}</div>
            <div className="text-xs text-gray-600">{space.location}</div>
            {currentPosition === space.id && (
              <div className="mt-2 text-2xl">🎮</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function GameBoardStory() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-xl font-bold mb-4">初期位置（スタート）</h2>
        <GameBoard currentPosition={0} />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">途中の位置</h2>
        <GameBoard currentPosition={5} />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">ゴール位置</h2>
        <GameBoard currentPosition={10} />
      </div>
    </div>
  );
}

export default GameBoard;