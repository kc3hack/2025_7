"use client";
import React from "react";

function PlayerStatus({ debt = 1000000, money = 0 }) {
  return (
    <div className="inline-block p-4 bg-white rounded-lg shadow-md border border-gray-200">
      <div className="flex flex-col gap-3">
        <div className="text-center">
          <h2 className="text-xl font-bold text-gray-800 mb-1">
            プレイヤーステータス
          </h2>
        </div>
        <div className="flex flex-col gap-2">
          <div className="flex justify-between items-center">
            <span className="text-red-600 font-bold">残りの借金:</span>
            <span className="text-red-600 font-bold">
              {debt.toLocaleString()}円
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-green-600 font-bold">現在の所持金:</span>
            <span className="text-green-600 font-bold">
              {money.toLocaleString()}円
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

function PlayerStatusStory() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-xl font-bold mb-4">初期状態</h2>
        <PlayerStatus />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">所持金があるとき</h2>
        <PlayerStatus debt={800000} money={50000} />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">借金完済に近いとき</h2>
        <PlayerStatus debt={100000} money={95000} />
      </div>
    </div>
  );
}

export default PlayerStatus;