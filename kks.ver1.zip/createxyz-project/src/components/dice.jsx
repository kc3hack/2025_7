"use client";
import React from "react";

function Dice({ onRoll, initialValue = 1 }) {
  const [value, setValue] = useState(initialValue);
  const [isRolling, setIsRolling] = useState(false);

  const handleClick = useCallback(() => {
    if (isRolling) return;

    setIsRolling(true);
    const newValue = Math.floor(Math.random() * 6) + 1;

    setTimeout(() => {
      setValue(newValue);
      setIsRolling(false);
      if (onRoll) {
        onRoll(newValue);
      }
    }, 1000);
  }, [isRolling, onRoll]);

  return (
    <div
      onClick={handleClick}
      className={`w-[100px] h-[100px] bg-white rounded-xl shadow-lg cursor-pointer flex items-center justify-center border-2 border-gray-200 ${
        isRolling ? "animate-spin" : "hover:bg-gray-50"
      }`}
    >
      <span
        className={`text-4xl font-bold ${
          isRolling ? "opacity-0" : "opacity-100"
        }`}
      >
        {value}
      </span>
      <style jsx global>{`
        @keyframes spin {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }
        .animate-spin {
          animation: spin 0.5s linear infinite;
        }
      `}</style>
    </div>
  );
}

function DiceStory() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-xl font-bold mb-4">通常のサイコロ</h2>
        <Dice />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">初期値6のサイコロ</h2>
        <Dice initialValue={6} />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">
          結果をコンソールに表示するサイコロ
        </h2>
        <Dice onRoll={(value) => console.log(`サイコロの目: ${value}`)} />
      </div>
    </div>
  );
}

export default Dice;